// Function to handle registration
async function handleRegistration(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const surname = document.getElementById('surname').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;
    const department = document.getElementById('department').value;

    try {
        const response = await fetch('http://localhost:3000/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username,
                surname,
                password,
                role,
                department
            })
        });

        const data = await response.json();

        if (response.ok) {
            alert('Registration successful!');
            window.location.href = 'login.html';
        } else {
            alert(data.error || 'Registration failed');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Registration failed');
    }
}

// Function to handle login
async function handleLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('http://localhost:3000/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username, 
                password
            })
        });

        const data = await response.json();

        if (response.ok) {
            // Store the token
            localStorage.setItem('token', data.token);
            localStorage.setItem('userRole', data.role);
            
            // Redirect based on role
            if (data.role === 'admin') {
                window.location.href = 'admin-landing.html';
            } else if (data.role === 'approver') {
                window.location.href = 'approver-portal.html';
            }
             else {
                window.location.href = 'employee-portal.html';
            }
        } else {
            alert(data.error || 'Login failed, you do not have ');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Login failed');
    }
}

// Add event listeners based on the current page
document.addEventListener('DOMContentLoaded', () => {
    const registrationForm = document.getElementById('registrationForm');
    const loginForm = document.getElementById('loginForm');

    if (registrationForm) {
        registrationForm.addEventListener('submit', handleRegistration);
    }

    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
});
