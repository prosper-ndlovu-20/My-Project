const express = require('express');
const app = express();
const port = 3000;  
const cors = require('cors');
const mysql = require('mysql');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const corsoptions = {
    origin: '*',
    optionsSuccessStatus: 200,
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
    credentials: true,
    allowedHeaders: ['Content-Type', 'Authorization']
};

app.use(cors(corsoptions));
app.use(express.json());  

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "1980",
    database: "project_db"
});

db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the MySQL database.');
});

app.get('/', (req, res) => {
    res.send('Hello World!');
});

// Endpoint to get departments
app.get('/api/departments', (req, res) => {
    const departments = ['IT', 'HR', 'Operations'];
    res.json(departments);
});

app.get('/api/users', (req, res) => {
    const sqlQuery = "SELECT * FROM users";
    db.query(sqlQuery, (err, results) => {
        if (err) {
            console.error('Error fetching data:', err);
            res.status(500).send('Error fetching data');
            return;
        }
        res.json(results);
    });
});

// Function to generate a random integer between min and max (inclusive)
function generateRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Function to check if a user_ID already exists
function checkUserIdExists(userId) {
    return new Promise((resolve, reject) => {
        db.query("SELECT user_ID FROM users WHERE user_ID = ?", [userId], (err, results) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(results.length > 0);
        });
    });
}

// Function to generate a unique user ID
async function generateUniqueUserId() {
    let userId;
    let exists = true;
    
    while (exists) {
        // Generate a random 6-digit number
        userId = generateRandomInt(100000, 999999);
        exists = await checkUserIdExists(userId);
    }
    
    return userId;
}

app.post('/api/register', async (req, res) => {
    try {
        const { username, surname, role, password, department } = req.body;
        
        // Validate role
        if (role !== 'admin' && role !== 'general' && role !== 'approver') {
            return res.status(400).json({ error: 'Invalid role. Must be either "admin" or "general" or "approver"' });
        }

        // Generate unique user ID
        const userId = await generateUniqueUserId();

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert user into database
        const sqlQuery = "INSERT INTO users (user_ID, username, surname, user_role, userPassword, department) VALUES (?, ?, ?, ?, ?, ?)";
        db.query(sqlQuery, [userId, username, surname, role, hashedPassword, department], (err, result) => {
            if (err) {
                console.error('Error registering user:', err);
                return res.status(500).json({ error: 'Error registering user, there is a problem with the database.' });
            }
            res.status(201).json({ message: 'User registered successfully' });
        });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});
// inserting data into the database
// const insertData = "INSERT INTO  Returnable_Equip(Sending_From, Destination, Department, Requesting_dept,Purpose, Request_Date, Driver_Name, Vehicle_Reg,Item_Code, Item_Description, SerialNumber, Quantity) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
// db.query(insertData, ['HQ', 'Branch1', 'IT', 'IT', 'Project Work', '2024-10-01', 'John Doe', 'ABC123', 'ITM001', 'Laptop', 'SN123456', 2], (
// Endpoint to update user details
app.put('/api/users/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const { username, surname, user_role, department } = req.body;

        // First check if the user exists
        const checkUserQuery = "SELECT * FROM users WHERE user_ID = ?";
        db.query(checkUserQuery, [userId], (err, results) => {
            if (err) {
                console.error('Error checking user:', err);
                return res.status(500).json({ error: 'Database error' });
            }

            if (results.length === 0) {
                return res.status(404).json({ error: 'User not found' });
            }

            // Update user details
            const updateQuery = "UPDATE users SET username = ?, surname = ?, user_role = ?, department = ? WHERE user_ID = ?";
            db.query(updateQuery, [username, surname, user_role, department, userId], (err, result) => {
                if (err) {
                    console.error('Error updating user:', err);
                    return res.status(500).json({ error: 'Error updating user' });
                }

                if (result.affectedRows === 0) {
                    return res.status(404).json({ error: 'User not found' });
                }

                res.json({ message: 'User updated successfully' });
            });
        });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Helper function to log activity
function logActivity(username, activity) {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19); // 'YYYY-MM-DD HH:MM:SS'
    const sql = "INSERT INTO Activity_logs (username, activity, timestamp) VALUES (?, ?, ?)";
    db.query(sql, [username, activity, timestamp], (err) => {
        if (err) {
            console.error('Error logging activity:', err);
        }
    });
}

app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        // Find user in database
        const sqlQuery = "SELECT * FROM users WHERE username = ?";
        db.query(sqlQuery, [username], async (err, results) => {
            if (err) {
                console.error('Error during login:', err);
                return res.status(500).json({ error: 'Error during login, user not found' });
            }

            if (results.length === 0) {
                return res.status(401).json({ error: 'Invalid credentials' });
            }
            const user = results[0];
            
            // Verify password
            const validPassword = await bcrypt.compare(password, user.userPassword);
            if (!validPassword) {
                return res.status(401).json({ error: 'Invalid credentials, wrong password' });
            }

            // Create JWT token
            const token = jwt.sign(
                { userId: user.user_ID, username: user.username, role: user.user_role },
                'your-secret-key', // In production, use environment variable
                { expiresIn: '1h' }
            );

            logActivity(user.username, `${user.username} has logged in to the system`);
            res.json({ token, role: user.user_role });
        });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

app.post('/api/logout', (req, res) => {
    const { username } = req.body;
    logActivity(username, `${username} has logged out of the system`);
    res.json({ message: 'Logout successful' });
});

app.delete('/api/users/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        // Check if user exists
        const checkUserQuery = "SELECT * FROM users WHERE user_ID = ?";
        db.query(checkUserQuery, [userId], (err, results) => {
            if (err) {
                console.error('Error checking user:', err);
                return res.status(500).json({ error: 'Database error' });
            }
            if (results.length === 0) {
                return res.status(404).json({ error: 'User not found' });
            }
            // Delete user
            const deleteQuery = "DELETE FROM users WHERE user_ID = ?";
            db.query(deleteQuery, [userId], (err, result) => {
                if (err) {
                    console.error('Error deleting user:', err);
                    return res.status(500).json({ error: 'Error deleting user' });
                }
                res.json({ message: 'User deleted successfully' });
            });
        });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Endpoint to get activity logs
app.get('/api/activity-logs', (req, res) => {
    const sql = "SELECT * FROM Activity_logs ORDER BY timestamp DESC";
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching activity logs:', err);
            return res.status(500).json({ error: 'Error fetching activity logs' });
        }
        res.json(results);
    });
});

// Endpoint to create an equipment request
app.post('/api/equiprequest', async (req, res) => {
    try {
        const {
            sending_from,
            Destination,
            Department,
            Requesting_dept,
            Purpose,
            Request_Date,
            Driver_Name,
            Vehicle_Reg,
            Item_Code,
            Item_Description,
            SerialNumber,
            Quantity,
            returnable
        } = req.body;

        // Basic validation
        if (!sending_from || !Destination || !Department || !Requesting_dept || !Purpose || !Request_Date || !Quantity) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        const qty = parseInt(Quantity, 10) || 0;
        const ret = (returnable === true || returnable === 1 || returnable === '1' || returnable === 'true') ? 1 : 0;

        const insertSql = `INSERT INTO Equipment (sending_from, Destination, Department, Requesting_dept, Purpose, Request_Date, Driver_Name, Vehicle_Reg, Item_Code, Item_Description, SerialNumber, Quantity, returnable) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
        const params = [sending_from, Destination, Department, Requesting_dept, Purpose, Request_Date, Driver_Name || null, Vehicle_Reg || null, Item_Code || null, Item_Description || null, SerialNumber || null, qty, ret];

        db.query(insertSql, params, (err, result) => {
            if (err) {
                console.error('Error inserting equipment request:', err);
                return res.status(500).json({ error: 'Error saving equipment request' });
            }
            res.status(201).json({ message: 'Equipment request submitted successfully' });
        });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

app.listen(port, () => {
    console.log("Server is running on port " + port);
})