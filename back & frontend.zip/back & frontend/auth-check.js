// Function to check if user is authenticated
function isAuthenticated() {
    const token = localStorage.getItem('token');
    if (!token) {
        return false;
    }

    // Check if token is expired
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        const expirationTime = payload.exp * 1000; // Convert to milliseconds
        if (Date.now() >= expirationTime) {
            // Token is expired, clear it
            localStorage.removeItem('token');
            localStorage.removeItem('userRole');
            return false;
        }
        return true;
    } catch (error) {
        console.error('Error checking token:', error);
        return false;
    }
}

// Function to check if user has required role
function hasRole(requiredRole) {
    const userRole = localStorage.getItem('userRole');
    return userRole === requiredRole;
}

// Function to redirect unauthorized users
function checkAccess(requiredRole) {
    if (!isAuthenticated()) {
        window.location.href = 'login.html';
        return;
    }

    if (requiredRole && !hasRole(requiredRole)) {
        alert('You do not have permission to access this page.');
        window.location.href = 'login.html';
        return;
    }
}

// Check authentication when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Get the current page name
    const currentPage = window.location.pathname.split('/').pop();
    
    // Define required roles for each page
    switch (currentPage) {
        case 'admin-landing.html':
            checkAccess('admin');
            break;
        case 'approver-portal.html':
            checkAccess('approver');
            break;
        case 'employee-portal.html':
            checkAccess('general');
            break;
        case 'user-management.html':
            checkAccess('admin');
            break;
        default:
            // For any other protected page, just check if user is authenticated
            checkAccess();
    }
});

// Logout function
 document.getElementById("Logout").addEventListener("click", (e) => {
    localStorage.removeItem("userRole");
    localStorage.removeItem("token");
    window.location.href = "login.html"
 })
